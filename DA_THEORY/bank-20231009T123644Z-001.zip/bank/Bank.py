#Importing User panel function and Admin panel functions
import user_panel as up
import admin_panel as ap

choice=0
while choice!=3:
    try:
        choice=int(input("""
                         1. Admin panel
                         2. User Panel
                         3. Quit
                         choice : """))
        match choice:
            case 1:
                ap.adminpanel()
            case 2:
                up.userpanel()
            case 3:
                print("You have quit")
            case _:
                print("Invalid Choice")
    except Exception as e:
        print("Error occured, ",e)