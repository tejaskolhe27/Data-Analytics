#Simmulation of SBI bank account

class bank():
    #counter for account number
    count=0  #MODIFY COUNT TO RETURN 2 DIGHT NUMBER WHILE BELOW 10
    #Defualt constructor
    def __init__(self,account_number="",user_name="",balance="",pin=""):
        bank.count=bank.count+1
        self.__account_number=str(account_number)+str(bank.count)
        self.__user_name=user_name
        self.__balance=balance
        self.__pin=pin
    def  __str__(self):
        return f"Account number: {self.__account_number}, User Name: {self.__user_name}, Account balance: {self.__balance}"
    
    #Getter function
    def get_account_number(self):
        return self.__account_number
    def get_user_name(self):
        return self.__user_name
    def get_balance(self):
        return self.__balance
    def get_pin(self):
        return self.__pin
    #Setter function
    def set_account_number(self,account_number):
        self.__account_number=account_number
    def set_user_name(self,user_name):
        self.__user_name=user_name
    
    
    
    