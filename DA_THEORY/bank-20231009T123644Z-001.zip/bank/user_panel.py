#Importing bank functions
import bank_functions as bnf

def userpanel():
    choice=0
    try:
        while choice!=8:
            choice=int(input("""
                             1. Check back balance
                             2. Withdraw money
                             3. 
                             4. Change PIN
                             5. Quit
                             choice : """))
            match choice:
                case 1:
                    bnf.check_balance()
                case 2:
                    bnf.withdrawmoney()
                case 3:
                    pass
                case 4:
                    pass
                case 5:
                    print("you have quit")
                case _:
                    print("Invalid choice")
    except Exception as e:
        print("Error occured, ",e)