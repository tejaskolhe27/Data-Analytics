#Importing bank functions
import bank_functions as bnf

def adminpanel():
    choice=0
    try:
        while choice!=6:
            choice=int(input("""
                             1. Add New bank Account 
                             2. Display all
                             3. Delete an account
                             4. Display data of an account (Search by Account number)
                             5. Display data of an account (search by name of account holder)
                             6. Quit
                             choice : """))
            match choice:
                case 1: #To add a new bank account. (Which is a attribute of admin)
                    bnf.addaccount()
                case 2: #To check all the back accounts. (A option needs to be added, for savings and current account)
                    bnf.displayall()
                case 3:
                    bnf.deleteaccount()
                case 4:
                    bnf.displaybyaccnum()
                case 5:
                    bnf.displaybyusernm()
                case 6:
                    print("""You have quit.
                          Thankyou!!! Visit again""")
                case _: #Default case. When user enters a imput which is not pertinent to menu
                    print("Invalid choice")
    except Exception as e:
        print("Error occured, ",e)
