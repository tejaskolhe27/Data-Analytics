#Bank system using File handling 
import bank_class

account_holder={}
#Checking if the accounr already exits (searchby account number)
def checkuserbyAN(acc_num):
    if len(account_holder)==0:  #Account holder does not exist
        return  1
    for key,values in account_holder.items():
        if values.get_account_number()==acc_num:  #Account already exists
            c_pin=values.get_pin()
            return 2, c_pin, key,values
    
#Checking if the account already exists (search by username)
def checkuserbyUN(username):
    if len(account_holder)==0:  #Account holder does not exist
        return  1
    for key,values in account_holder.items():
        a=str(values.get_user_name())
        if a==str(username):  #Account already exists   
            c_pin=values.get_pin()
            return 2, c_pin, key, values

#Adding new bank account (MODIFY TO ASK ACCOUNT TYPE, Attribute of the admin panel)
def addaccount():
    '''
    To add a new account in the database. (Attribute of the admin panel)
    --------------------------------------------------------------------
    Args:
    -------
        name : Account object will be made in the entered name
        balance : Amount to be added over the minimum account balance (5000 rs.)
        pin : user account will be secured with the entered pin (can only be accessed by the user)
        
    method:
    -------
        1. Name of the new user will be enterd and will be checked into the database. If user already exists, kernel will show
            the prompt "This username already exists, Please change user name"
        2. If user name does not exist in the database. then further arguments will be asked from the user.
        3. An object of the bank class will be made and will be added into the database

    Returns
    -------
    None.

    '''
    try:    
        name=input("Please enter the name of the Account holder : ")
        status=checkuserbyUN(name)
        if status==2: #User exists 
            print("This username already exists, Please change user name ")
        else:
            min_balance_essage="****While opening new account minimum balance is 5000****"
            print(min_balance_essage.upper())
            balance=int(input("Please enter amount to add (except minimum required balance) : "))
            pin=int(input("Set Account pin : "))
            final_balance=5000+balance
            obj=bank_class.bank('SBI0230980',name,final_balance,pin)
            obj_name=obj.get_account_number()
            account_holder[obj_name]=obj
    except Exception as e:
        print("Error occured, ",e)

#Display record of all account holders (Attribute of the admin panel)
def displayall():
    '''
    Function to show all the user data in the database
    --------------------------------------------------
    Args:
    -------
    None.
    
    Method:
    -------
        1. Kernel will show all the data's of the user in the database

    Returns
    -------
    None.

    '''
    print("Data of all the account in the bank is as follows:")
    for value in account_holder.values(): #To iterate through the loop
        print(value.get_user_name(),"------",str(value))

#Check bank balance (searching by account number, Attribute of admin)
def check_balance():
    '''
    function to check the account balance. (Attribute of the userpanel)
    -------------------------------------------------------------------
    Args:
    -------
        account number : Enter account number of user, checking database for existing user id's
        pin : Required for confirmation of the account
    Method:
    -------
        1. Will match the account number and pin number with the existing users. if not found, will show the prompt 
            "Account does not exist". If pin does not match with the account pin, will show the prompt "Invalid pin"
        2. If account number and the pin matches. Kernel will show prompt displaying the account balance.

    Returns
    -------
    None.

    '''
    try: #Exception handling
        account_number=input("Enter the account number to check balance : ")
        pin=input("Please enter the Account Pin : ") #To check the user credibility
        status,c_pin,key,value=checkuserbyAN(account_number)
        if status==2: #Account exist into the database
            if str(c_pin)==str(pin): #Entered pin matched with account pin
                print(f"Account Balance of {account_number} is", str(value.get_balance()))
            else:
                print("Invalid Account PIN")
        else:
            print("Account does not exist")
    except Exception as e: #Except block for the try block
        print("Error occured, ",e)

#Withdraw money. (Attribute of User)
def withdrawmoney():
    '''
    To withdarw money from the account. Attribute of the userpanel
    --------------------------------------------------------------
    Args:
    -------
        account number : Enter account number of user, checking database for existing user id's
        money : Amount to be withdrawn by the user
        pin : Required for confirmation of the account
        
    Method: 
    -------
        1. Will match the account number and pin number with the existing users. if not found, will show the prompt 
            "Account does not exist". If pin does not match with the account pin, will show the prompt "Invalid pin"
        2. If the account balance is lower than the entered amount. Will show the prompt "Insufficient account balance"
        
    Returns
    -------
    None.

    '''
    try:
        account_number=input("Enter the account number to check balance : ")
        money=int(input("""Enter the amount to be withdrawn
                        (Money will be withdraws in 100, 500 & 2000 unit notes)
                        Amount : """))
        pin=input("Please enter Security Pin : ")
        status,c_pin,key,value=checkuserbyAN(account_number)
        if status==2:
            if str(c_pin)==str(pin):
                if int(value.get_balance())<int(money):
                    print("Insufficient account balance")
                else:
                    balance=int(value.get_balance())-int(money)
                    print(f"Account balance : {balance}")
            else:
                print("Invalid Account PIN")
        else:
            print("Account does not exist")
    except Exception as e:
        print("Error occured, ",e)

#To delete an account. (Attribute of Admin)
def deleteaccount():
    """
    To delete a bank account (Attribute of the admin panel)
    -------------------------------------------------------
    Args: 
    -------
        Account_number : Enter account number of user requesting for account deactivation
        pin : Required for confirmation of the account
    
    method: 
    -------    
            1. if the account is present then will ask for the permission of the admin, for the final confirmation to proceed with 
                 account deletion
            2. if account is found and the pin does not match with the account pin, will show the prompt that account pin invalid
            3. if the account is not found, then will show the prompt that account does not exist.
            4. after confirmation from the user for account deletion, the account will be deleted and all the records pertaining to 
                to the user and account will be removed
    return
    -------
    None.
            
    """
    try:
        account_number=input("Enter the account number to delete : ")
        pin=input("Please enter Security Pin : ")
        status,c_pin,key,value=checkuserbyAN(account_number)
        print(f"status = {status}")
        if status==2:
            print(c_pin)
            if str(c_pin)==str(pin):
                ch=input("Please confirm if you really want to delete : (y/n) : ")
                ch=ch.lower()
                if ch=='y':
                   account_holder.pop(key)
                   print("Account deleted sucessfully")
                else:
                    print("Account found but not deleted")
            else:
                print("Invalid account pin")
        else:
            print("Account does not exist")
    except Exception as e:
        print("error occured, ",e)
        
#To check acoout details, searching by account number
def displaybyaccnum():
    '''
    To check account details (Searching by account number, Attribute of the admin panel)
    ------------------------------------------------------------------------------------
    Args: 
    -------
        Account_number : Enter account number of user requesting for account deactivation
        pin : Required for confirmation of the account
    
    method: 
    -------    
            1. Will match the account number and pin number with the existing users. if not found, will show the prompt 
                "Account does not exist". If pin does not match with the account pin, will show the prompt "Invalid pin"
            2. If account number and the pin matches. Kernel will show prompt displaying the account details.

    Returns
    -------
    None.

    '''
    try:
        account_number=input("Enter the account number : ")
        pin=input("Please enter Security Pin : ")
        status,c_pin,key,value=checkuserbyAN(account_number)
        if status==2:
            if str(c_pin)==str(pin):
                print(f"Account details are as follows --------",str(value))
            else:
                print("Invalid Account PIN")
        else:
            print("Account does not exist")
    except Exception as e:
        print("Error occured, ",e)
        
#To check account details (searching by username, Attribute of the admin panel)
def displaybyusernm():
    '''
    To check account details (Searching by account number, Attribute of the admin panel)
    ------------------------------------------------------------------------------------
    Args: 
    -------
        Account_number : Enter account number of user requesting for account deactivation
        pin : Required for confirmation of the account
    
    method: 
    -------    
            1. Will match the user name and pin number with the existing users. if not found, will show the prompt 
                "Account does not exist". If pin does not match with the account pin, will show the prompt "Invalid pin"
            2. If account number and the pin matches. Kernel will show prompt displaying the account details.

    Returns
    -------
    None.

    '''
    try:
        user_name=input("Enter the User name : ")
        pin=input("Please enter Security Pin : ")
        status,c_pin,key,value=checkuserbyUN(user_name)
        if status==2:
            if str(c_pin)==str(pin):
                print(f"Account details are as follows --------",str(value))
            else:
                print("Invalid Account PIN")
        else:
            print("User does not exist")
    except Exception as e:
        print("Error occured, ",e)
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        